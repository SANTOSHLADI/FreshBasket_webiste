# Fruits and vegetables e-commerce

An e-commerce web app build on top of react to facilitate users to buy fruits products online and offer shop owner easy and convenient management.

## Instructions
1. npm install
2. npm run start

[Checkout Deployed version of the app](https://fruits-and-vegetables-market.netlify.app/)

